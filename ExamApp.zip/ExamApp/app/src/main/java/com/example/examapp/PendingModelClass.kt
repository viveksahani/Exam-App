package com.example.examapp

class PendingModelClass(
    val id:String,
    val name:String,
    val dob:String,
    val password:String
) {
}