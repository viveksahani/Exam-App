package com.example.examapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DbAttempedTest(context: Context, factory: SQLiteDatabase.CursorFactory?) :
    SQLiteOpenHelper(
        context,
        DbQuestionTable.DATABASE_NAME, factory,
        DbQuestionTable.DATABASE_VERSION
    ) {
    val dbTest = DbTest(context, null)

    companion object {
        const val DATABASE_VERSION = 9
        const val DATABASE_NAME = "ExamApp"
        const val TABLE_NAME = "AttemptedTestTable"
        const val COL_RESULT_ID = "resultId"
        const val COL_STUDENT_ID = "studentId"
        const val COL_TEST_ID = "testId"
        const val COL_TEST_NAME = "testName"
        const val COL_TOTAL_MARKS = "totalMarks"
        const val COL_OBTAINED_MARKS = "obtainedMarks"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val query =
            ("CREATE TABLE " + TABLE_NAME + " (" + COL_RESULT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COL_STUDENT_ID + " INTEGER, " + COL_TEST_ID + " INTEGER, " + COL_TEST_NAME + " TEXT, " + COL_TOTAL_MARKS + " TEXT, " + COL_OBTAINED_MARKS + " TEXT);")
        db?.execSQL(query)
    }

    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {
        db?.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME)
        onCreate(db)
    }

    fun addAttemptedTest(
        studentId: String,
        testId: String,
        testName: String,
        totalMarks: String,
        obtainedMarks: String
    ) {
        val values = ContentValues()
        values.put(COL_STUDENT_ID, studentId)
        values.put(COL_TEST_ID, testId)
        values.put(COL_TEST_NAME, testName)
        values.put(COL_TOTAL_MARKS, totalMarks)
        values.put(COL_OBTAINED_MARKS, obtainedMarks)
        val db = this.writableDatabase
        db.insert(TABLE_NAME, null, values)
        db.close()
    }

    fun updateMarksObtained(userId: String, testId: String, newTotalMarks: String, newMarksObtained: String) {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(COL_TOTAL_MARKS, newTotalMarks)
        contentValues.put(COL_OBTAINED_MARKS, newMarksObtained)
        val selection = "$COL_STUDENT_ID = ? AND $COL_TEST_ID = ?"
        val selectionArgs = arrayOf(userId, testId)

        db.update(TABLE_NAME, contentValues, selection, selectionArgs)
    }

    fun isAttempted(userId:String, testId:String):Boolean {
        val db = this.readableDatabase
        val cursor =
            db.rawQuery("SELECT * FROM $TABLE_NAME WHERE $COL_STUDENT_ID = ? AND $COL_TEST_ID = ?", arrayOf(userId, testId))
        if(cursor.moveToFirst()) {
            return true
        }
        return false
    }
    fun getAllAttemptedTest(user: String): MutableList<AttemptedTestModel> {
        val list = mutableListOf<AttemptedTestModel>()
        val db = this.readableDatabase
        val cursor =
            db.rawQuery("SELECT * FROM $TABLE_NAME WHERE $COL_STUDENT_ID = ?", arrayOf(user))
        cursor?.moveToFirst()
        while (!cursor?.isAfterLast!!) {
            var index = cursor.getColumnIndex("testId")
            val testId = cursor.getString(index)

            index = cursor.getColumnIndex("testName")
            val testName = cursor.getString(index)

            index = cursor.getColumnIndex("totalMarks")
            val totalMarks = cursor.getString(index)

            index = cursor.getColumnIndex("obtainedMarks")
            val obtainedMarks = cursor.getString(index)

            val isNegative = dbTest.isNegative(testId)
            val noOfQuestions = totalMarks

            list.add(
                AttemptedTestModel(
                    testId,
                    testName,
                    totalMarks,
                    obtainedMarks,
                    isNegative,
                    noOfQuestions
                )
            )
            cursor.moveToNext()
        }
        cursor.close()
        db.close()
        return list
    }
}