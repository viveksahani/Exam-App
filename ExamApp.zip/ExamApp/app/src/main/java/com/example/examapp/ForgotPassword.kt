package com.example.examapp

import android.app.DatePickerDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import java.util.*

class ForgotPassword : AppCompatActivity() {
    lateinit var id: EditText
    lateinit var dob:EditText
    lateinit var calendarIcon:ImageView
    lateinit var newPassword: EditText
    lateinit var confirmNewPassword: EditText
    lateinit var reset_btn:Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)
        id = findViewById(R.id.id)
        dob = findViewById(R.id.dob)
        calendarIcon = findViewById(R.id.calendarIcon)
        newPassword = findViewById(R.id.password)
        confirmNewPassword = findViewById(R.id.confirmPassword)
        reset_btn = findViewById(R.id.reset_btn)

        reset_btn.setOnClickListener {
            Toast.makeText(this, "reset clicked", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
    fun showDatePickerDialog(view: View) {

        val calendar = Calendar.getInstance()
        val currentYear = calendar.get(Calendar.YEAR)
        val currentMonth = calendar.get(Calendar.MONTH)
        val currentDay = calendar.get(Calendar.DAY_OF_MONTH)
        val datePickerDialog = DatePickerDialog(
            this,
            { view, year, month, dayOfMonth ->
                val selectedDate = "$dayOfMonth/${month + 1}/$year"
                dob.setText(selectedDate)
            },
            // Set initial date (optional)
            currentYear,
            currentMonth,   // (0-11)
            currentDay
        )
        datePickerDialog.show()
    }
}