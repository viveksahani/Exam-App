package com.example.examapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class ProfileStudent : AppCompatActivity() {

    lateinit var id:String
    lateinit var nav_name: TextView
    lateinit var drawerLayout: DrawerLayout
    lateinit var actionBarDrawerToggle: ActionBarDrawerToggle
    lateinit var navigationView: NavigationView
    lateinit var nav_headerView: View
    lateinit var dp: ImageView


    lateinit var attempTest: LinearLayout
    lateinit var availableTest: LinearLayout
    lateinit var scoreCard: LinearLayout
    lateinit var listAttemptedTest: ListView
    lateinit var refreshBtn: ImageView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile_student)


        id = intent.getStringExtra("id").toString()
        drawerLayout = findViewById(R.id.drawer_layout_student)
        actionBarDrawerToggle =
            ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close)
        drawerLayout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState()
        supportActionBar?.setDisplayHomeAsUpEnabled(true)


        navigationView = findViewById(R.id.navigationStudent)
        nav_headerView = navigationView.getHeaderView(0)
        dp = nav_headerView.findViewById(R.id.dp)
        nav_name = nav_headerView.findViewById(R.id.navName)

        dp.background = getDrawable(R.drawable.student)
        val tmp = DbStudent(this, null)
        val nm = id?.let { tmp.getStudentName(it) }
        nav_name.text = nm

        navigationView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.home -> {
                    Toast.makeText(this, "Home selected", Toast.LENGTH_SHORT).show()
                }
                R.id.logout -> {
                    val builder = AlertDialog.Builder(this)
                    builder.setTitle("Logout !")
                    builder.setMessage(
                        "Are you sure to Logout ?"
                    )
                    builder.setPositiveButton("Logout") { dialog, which ->
                        onBackPressed()
                    }
                    builder.setNegativeButton("Cancel") { dialog, which ->
                    }
                    builder.setCancelable(true)
                    val dialog: AlertDialog = builder.create()
                    dialog.show()
                }
            }
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }


        attempTest = findViewById(R.id.attempt_test)
        availableTest = findViewById(R.id.available_test)
        scoreCard = findViewById(R.id.score_card)
        listAttemptedTest = findViewById(R.id.list_attempted_test)
        refreshBtn = findViewById(R.id.refreshBtn)
        var list: MutableList<AttemptedTestModel>
        val db = DbAttempedTest(this, null)
        list = db.getAllAttemptedTest(id)
        list.reverse()
        var adapter = AdapterClassAttemptedTest(this, R.layout.attempted_test_list, list)
        listAttemptedTest.adapter = adapter
        var desiredHeight = calculateDesiredHeight(listAttemptedTest)
        var params = listAttemptedTest.layoutParams
        params.height = desiredHeight
        listAttemptedTest.layoutParams = params
        listAttemptedTest.requestLayout()

        refreshBtn.setOnClickListener {
            list = db.getAllAttemptedTest(id)
            list.reverse()
            adapter = AdapterClassAttemptedTest(this, R.layout.attempted_test_list, list)
            listAttemptedTest.adapter = adapter
            desiredHeight = calculateDesiredHeight(listAttemptedTest)
            params = listAttemptedTest.layoutParams
            params.height = desiredHeight
            listAttemptedTest.layoutParams = params
            listAttemptedTest.requestLayout()
        }

        attempTest.setOnClickListener {
            // have to implement today till night
            // 2nd

            val dialogBuilder = android.app.AlertDialog.Builder(this)
            val dialogView = View.inflate(this, R.layout.ask_testid, null)
            val testId = dialogView.findViewById<EditText>(R.id.testId)
            val submitBtn = dialogView.findViewById<Button>(R.id.submitBtn)
            val cancelBtn = dialogView.findViewById<Button>(R.id.cancelBtn)

            val alertDialog = dialogBuilder.setView(dialogView).create()
            alertDialog.setCancelable(false)

            submitBtn.setOnClickListener {
                if (testId.text.isNotEmpty()) {
                    val intent = Intent(this, GiveTest::class.java)
                    intent.putExtra("userId", id)
                    intent.putExtra("testId", testId.text.toString())
                    startActivity(intent)
                    alertDialog.dismiss()
                }
            }
            cancelBtn.setOnClickListener {
                alertDialog.dismiss()
            }
            alertDialog.show()
        }
        availableTest.setOnClickListener {
            // have to implement today till night
            // 1st
            // done

            val intent = Intent(this, AvailableTestActivity::class.java)
            intent.putExtra("userId", id)
            startActivity(intent)

        }
        scoreCard.setOnClickListener {
            // have to implement today till night
            // 3rd
        }

    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            true
        } else super.onOptionsItemSelected(item)
    }
    override fun onBackPressed() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Logout !")
        builder.setMessage(
            "Are you sure to Logout ?"
        )
        builder.setPositiveButton("Logout") { dialog, which ->
            super.onBackPressed()
        }
        builder.setNegativeButton("Cancel") { dialog, which ->
        }
        builder.setCancelable(true)
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }
    private fun calculateDesiredHeight(listView: ListView): Int {
        val adapter = listView.adapter
        var totalHeight = 0
        val itemCount = adapter.count
        if (itemCount > 0) {
            val listItem = adapter.getView(0, null, listView)
            listItem.measure(
                View.MeasureSpec.UNSPECIFIED,
                View.MeasureSpec.UNSPECIFIED
            )
            totalHeight = listItem.measuredHeight * itemCount
            totalHeight += (listView.dividerHeight * (itemCount - 1))
        }
        return totalHeight
    }
}