package com.example.examapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView

class AvailableTestActivity : AppCompatActivity() {
    lateinit var listAvailableTest: ListView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_available_test)

        listAvailableTest = findViewById(R.id.list_available_test)
        var list: MutableList<TestModel>
        val userId = intent.getStringExtra("userId").toString()

        val db = DbTest(this, null)
        list = db.getTestOfAllTeacher()

        var adapter = AdapterClassStudentTest(this, R.layout.test_view_student, list)
        listAvailableTest.adapter = adapter
        adapter.notifyDataSetChanged()
    }
}