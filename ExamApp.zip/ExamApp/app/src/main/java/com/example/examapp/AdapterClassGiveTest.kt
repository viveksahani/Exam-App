package com.example.examapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView

class AdapterClassGiveTest(
    context: Context,
    var resource: Int,
    var objects: MutableList<GiveTestModel>
) : ArrayAdapter<GiveTestModel>(context, resource, objects) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val layoutInflater: LayoutInflater = LayoutInflater.from(context)
        val view: View = layoutInflater.inflate(resource, null)

        val questionId: TextView = view.findViewById(R.id.question_id)
        val questionTxt: TextView = view.findViewById(R.id.questionTxt)
        val radioGroup: RadioGroup = view.findViewById(R.id.option_selected)
        val optionA: RadioButton = view.findViewById(R.id.optionA)
        val optionB: RadioButton = view.findViewById(R.id.optionB)
        val optionC: RadioButton = view.findViewById(R.id.optionC)
        val optionD: RadioButton = view.findViewById(R.id.optionD)
        val mItem: GiveTestModel = objects[position]
        val ans = mItem.ansTxt
        questionTxt.text = mItem.questionTxt
        questionId.text = "ID: " + mItem.questionId
        optionA.text = mItem.optionA
        optionB.text = mItem.optionB
        optionC.text = mItem.optionC
        optionD.text = mItem.optionD
        var correct_ans = ""
        if(ans.lowercase() == "a") {
            correct_ans = mItem.optionA
        }
        else if(ans.lowercase() == "b") {
            correct_ans = mItem.optionB
        }
        else if(ans.lowercase() == "c") {
            correct_ans = mItem.optionC
        }
        else if(ans.lowercase() == "d") {
            correct_ans = mItem.optionD
        }
        var optionSelected = ""
        radioGroup.setOnCheckedChangeListener { group, checkedId ->
            val radioClicked: RadioButton = view.findViewById(checkedId)
            optionSelected = radioClicked.text.trim().toString()
            mItem.check = optionSelected == correct_ans
        }
        return view
    }
}