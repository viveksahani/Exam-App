package com.example.examapp

import android.app.AlertDialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*

class AdapterClassReviewDelete(
    context: Context,
    var resource: Int,
    var objects: MutableList<QuestionModel>
) : ArrayAdapter<QuestionModel>(context, resource, objects) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val layoutInflater: LayoutInflater = LayoutInflater.from(context)
        val view: View = layoutInflater.inflate(resource, null)
        val questionId: TextView = view.findViewById(R.id.question_id)
        val questionTxt: TextView = view.findViewById(R.id.questionTxt)
        val optionA:TextView = view.findViewById(R.id.optionA)
        val optionB:TextView = view.findViewById(R.id.optionB)
        val optionC:TextView = view.findViewById(R.id.optionC)
        val optionD:TextView = view.findViewById(R.id.optionD)
        val ansTxt:TextView = view.findViewById(R.id.ansTxt)
        val deleteBtn:Button = view.findViewById(R.id.delete_btn)
        val editBtn:Button = view.findViewById(R.id.edit_btn)

        val question_view_only:LinearLayout = view.findViewById(R.id.question_view_only)
        val question_editable:LinearLayout = view.findViewById(R.id.question_editable)

        val questionTxt_editable: EditText = view.findViewById(R.id.questionTxt_editable)
        val questionId_editable: TextView = view.findViewById(R.id.question_id_editable)
        val optionA_editable: EditText = view.findViewById(R.id.optionA_editable)
        val optionB_editable:EditText = view.findViewById(R.id.optionB_editable)
        val optionC_editable:EditText = view.findViewById(R.id.optionC_editable)
        val optionD_editable:EditText = view.findViewById(R.id.optionD_editable)
        val ansTxt_editable:EditText = view.findViewById(R.id.ansTxt_editable)
        val updateBtn:Button = view.findViewById(R.id.updateBtn)


        val mItem: QuestionModel = objects[position]
        val qusId = mItem.questionId
        questionTxt.text = mItem.questionTxt
        questionId.text = questionId.text.toString() + qusId
        optionA.text = mItem.optionA
        optionB.text = mItem.optionB
        optionC.text = mItem.optionC
        optionD.text = mItem.optionD
        ansTxt.text = mItem.ansTxt

        questionTxt_editable.setText(mItem.questionTxt)
        questionId_editable.text = questionId.text.toString() + qusId
        optionA_editable.setText(mItem.optionA)
        optionB_editable.setText(mItem.optionB)
        optionC_editable.setText(mItem.optionC)
        optionD_editable.setText(mItem.optionD)
        ansTxt_editable.setText(mItem.ansTxt)

        question_editable.visibility = View.GONE

        deleteBtn.setOnClickListener {

            val dialogBuilder = AlertDialog.Builder(context)
            val dialogView = View.inflate(context, R.layout.delete_alert, null)

            val submitBtn = dialogView.findViewById<Button>(R.id.submitBtn)
            val cancelBtn = dialogView.findViewById<Button>(R.id.cancelBtn)

            val alertDialog = dialogBuilder.setView(dialogView).create()
            alertDialog.setCancelable(false)

            submitBtn.tag = position
            submitBtn.setOnClickListener {
                val deleteItem = objects[it.tag as Int]
                objects.remove(deleteItem)
                notifyDataSetChanged()

                val db = DbQuestionTable(context, null)
                db.deleteSelectedQuestion(qusId)
                alertDialog.dismiss()
            }
            cancelBtn.setOnClickListener {
                alertDialog.dismiss()
            }
            alertDialog.show()

        }

        editBtn.setOnClickListener {
            question_view_only.visibility = View.GONE
            question_editable.visibility = View.VISIBLE
        }

        updateBtn.setOnClickListener {
            val dialogBuilder = AlertDialog.Builder(context)
            val dialogView = View.inflate(context, R.layout.update_alert, null)
            val submitBtn = dialogView.findViewById<Button>(R.id.submitBtn)
            val cancelBtn = dialogView.findViewById<Button>(R.id.cancelBtn)

            val alertDialog = dialogBuilder.setView(dialogView).create()
            alertDialog.setCancelable(false)

            submitBtn.setOnClickListener {
                val str = ansTxt_editable.text.trim().toString().lowercase()
                if (questionTxt_editable.text.isNotEmpty() && optionA_editable.text.isNotEmpty() && optionB_editable.text.isNotEmpty() && optionC_editable.text.isNotEmpty() && optionD_editable.text.isNotEmpty() && ansTxt_editable.text.isNotEmpty() && (str == "a" || str == "b" || str == "c" || str == "d")) {
                    val db = DbQuestionTable(context, null)
                    db.updateQuestion(
                        qusId,
                        questionTxt_editable.text.toString(),
                        optionA_editable.text.toString(),
                        optionB_editable.text.toString(),
                        optionC_editable.text.toString(),
                        optionD_editable.text.toString(),
                        ansTxt_editable.text.toString()
                    )
                    Toast.makeText(context, "updated", Toast.LENGTH_SHORT).show()

                    var list: ArrayList<String> = ArrayList()
                    val db2 = DbQuestionTable(context, null)
                    list = db2.getParticularQuestion(qusId)

                    questionTxt.text = list[0]
                    optionA.text = list[1]
                    optionB.text = list[2]
                    optionC.text = list[3]
                    optionD.text = list[4]
                    ansTxt.text = list[5]

                    question_editable.visibility = View.GONE
                    question_view_only.visibility = View.VISIBLE
                }
                else {
                    Toast.makeText(context, "enter ans correctly", Toast.LENGTH_SHORT).show()
                }
                alertDialog.dismiss()
            }

            cancelBtn.setOnClickListener {
                alertDialog.dismiss()
            }
            alertDialog.show()
        }

        return view
    }
}