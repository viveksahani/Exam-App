package com.example.examapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog

class PendingAdapterClassAdmin(
    context: Context,
    var resource: Int,
    var objects: MutableList<PendingModelClass>
) : ArrayAdapter<PendingModelClass>(context, resource, objects) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val layoutInflater: LayoutInflater = LayoutInflater.from(context)
        val view: View = layoutInflater.inflate(resource, null)
        val idTxt: TextView = view.findViewById(R.id.userId)
        val name: TextView = view.findViewById(R.id.name)
        val dob: TextView = view.findViewById(R.id.dob)
        val rejectBtn: Button = view.findViewById(R.id.rejectBtn)
        val acceptBtn: Button = view.findViewById(R.id.approveBtn)
        val mItem: PendingModelClass = objects[position]
        idTxt.text = mItem.id
        name.text = mItem.name
        dob.text = mItem.dob
        rejectBtn.tag = position
        acceptBtn.tag = position
        rejectBtn.setOnClickListener {
            val temp = DbPendingAdmin(context, null)
            if (temp.deleteUser(mItem.id)) {
                var item_delete = objects.get(it.tag as Int)
                objects.remove(item_delete)
                notifyDataSetChanged()
            }
        }
        acceptBtn.setOnClickListener {
            val builder = AlertDialog.Builder(context)
            builder.setTitle("Confirmation !")
            builder.setMessage(
                "Confirm to add this Student ?"
            )
            builder.setPositiveButton("Yes") { dialog, which ->
                val temp = DbAdmin(context, null)
                temp.addAdmin(
                    mItem.id,
                    mItem.name,
                    mItem.dob,
                    mItem.password
                )
                val temp2 = DbPendingAdmin(context, null)
                if (temp2.deleteUser(mItem.id)) {
                    val item_delete = objects.get(it.tag as Int)
                    objects.remove(item_delete)
                }
                notifyDataSetChanged()
            }
            builder.setNegativeButton("No") { dialog, which ->
            }
            builder.setCancelable(true)
            val dialog: AlertDialog = builder.create()
            dialog.show()
        }
        return view
    }
}