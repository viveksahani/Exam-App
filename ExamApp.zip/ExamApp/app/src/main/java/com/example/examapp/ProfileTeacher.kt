package com.example.examapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import java.text.SimpleDateFormat
import java.util.*

class ProfileTeacher : AppCompatActivity() {
    lateinit var id: String
    lateinit var nav_name: TextView
    lateinit var drawerLayout: DrawerLayout
    lateinit var actionBarDrawerToggle: ActionBarDrawerToggle
    lateinit var navigationView: NavigationView
    lateinit var nav_headerView: View
    lateinit var dp: ImageView

    lateinit var createTestBtn: LinearLayout
    lateinit var addQuestionBtn: LinearLayout
    lateinit var reviewDeleteBtn: LinearLayout
    lateinit var editQuestionBtn: LinearLayout
    lateinit var deleteTestBtn:LinearLayout
    lateinit var searchBox: androidx.appcompat.widget.SearchView
    lateinit var listTest: ListView
    lateinit var refreshBtn: ImageView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile_teacher)


        refreshBtn = findViewById(R.id.refreshBtn)
        createTestBtn = findViewById(R.id.createTestBtn)
        addQuestionBtn = findViewById(R.id.addQuestionBtn)
        reviewDeleteBtn = findViewById(R.id.reviewDeleteBtn)
        editQuestionBtn = findViewById(R.id.edit_question_btn)
        deleteTestBtn = findViewById(R.id.delete_test)

        searchBox = findViewById(R.id.search_box)
        listTest = findViewById(R.id.list_test)
        var list: MutableList<TestModel>

        id = intent.getStringExtra("id").toString()
        drawerLayout = findViewById(R.id.drawer_layout_teacher)
        actionBarDrawerToggle =
            ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close)
        drawerLayout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState()
        supportActionBar?.setDisplayHomeAsUpEnabled(true)


        navigationView = findViewById(R.id.navigationTeacher)
        nav_headerView = navigationView.getHeaderView(0)
        dp = nav_headerView.findViewById(R.id.dp)
        nav_name = nav_headerView.findViewById(R.id.navName)


        val db = DbTest(this, null)
        list = db.getAllTest(id)
        list.reverse()
        var adapter = AdapterClassTest(this, R.layout.test_view_teacher, list)
        listTest.adapter = adapter
        var desiredHeight = calculateDesiredHeight(listTest)
        var params = listTest.layoutParams
        params.height = desiredHeight
        listTest.layoutParams = params
        listTest.requestLayout()

        refreshBtn.setOnClickListener {
            list = db.getAllTest(id)
            list.reverse()
            adapter = AdapterClassTest(this, R.layout.test_view_teacher, list)
            listTest.adapter = adapter
            desiredHeight = calculateDesiredHeight(listTest)
            params = listTest.layoutParams
            params.height = desiredHeight
            listTest.layoutParams = params
            listTest.requestLayout()
        }
        dp.background = getDrawable(R.drawable.teacher)
        val tmp = DbTeacher(this, null)
        val nm = id?.let { tmp.getTeacherName(it) }
        nav_name.text = nm
        navigationView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.home -> {
                    Toast.makeText(this, "Home selected", Toast.LENGTH_SHORT).show()
                }
                R.id.logout -> {
                    val builder = AlertDialog.Builder(this)
                    builder.setTitle("Logout !")
                    builder.setMessage(
                        "Are you sure to Logout ?"
                    )
                    builder.setPositiveButton("Logout") { dialog, which ->
                        onBackPressed()
                    }
                    builder.setNegativeButton("Cancel") { dialog, which ->
                    }
                    builder.setCancelable(true)
                    val dialog: AlertDialog = builder.create()
                    dialog.show()
                }
            }
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }

        createTestBtn.setOnClickListener {

            val dialogBuilder = android.app.AlertDialog.Builder(this)
            val dialogView = View.inflate(this, R.layout.create_test, null)

            val date: TextView = dialogView.findViewById(R.id.date_txt)
            val testName: EditText = dialogView.findViewById(R.id.test_name)
            val radioGroup: RadioGroup = dialogView.findViewById(R.id.radioBtn)
            val submitBtn = dialogView.findViewById<Button>(R.id.submitBtn)
            val cancelBtn = dialogView.findViewById<Button>(R.id.cancelBtn)

            val alertDialog = dialogBuilder.setView(dialogView).create()
            alertDialog.setCancelable(false)

            date.text = getCurrentDate()
            var isNegative = ""
            radioGroup.setOnCheckedChangeListener { group, checkedId ->
                val radioClicked: RadioButton = dialogView.findViewById(checkedId)
                isNegative = radioClicked.text.trim().toString()
            }

            submitBtn.setOnClickListener {
                if (testName.text.isNotEmpty() && isNegative != "") {
                    val temp = DbTest(this, null)
                    temp.addTest(
                        id,
                        testName.text.toString(),
                        date.text.toString(),
                        isNegative
                    )
                    Toast.makeText(this, "Added, Refresh the page.", Toast.LENGTH_SHORT).show()
                    alertDialog.dismiss()
                }
            }

            cancelBtn.setOnClickListener {
                alertDialog.dismiss()
            }

            alertDialog.show()
        }
        addQuestionBtn.setOnClickListener {
            val dialogBuilder = android.app.AlertDialog.Builder(this)
            val dialogView = View.inflate(this, R.layout.add_question_by_testid, null)
            val testId = dialogView.findViewById<EditText>(R.id.testId)
            val questionTxt = dialogView.findViewById<EditText>(R.id.questionTxt)
            val optionA = dialogView.findViewById<EditText>(R.id.optionA)
            val optionB = dialogView.findViewById<EditText>(R.id.optionB)
            val optionC = dialogView.findViewById<EditText>(R.id.optionC)
            val optionD = dialogView.findViewById<EditText>(R.id.optionD)
            val radioAns = dialogView.findViewById<RadioGroup>(R.id.ans)
            val submitBtn = dialogView.findViewById<Button>(R.id.submitBtn)
            val cancelBtn = dialogView.findViewById<Button>(R.id.cancelBtn)
            val alertDialog = dialogBuilder.setView(dialogView).create()
            alertDialog.setCancelable(false)
            var ans = ""
            radioAns.setOnCheckedChangeListener { group, checkedId ->
                val radioClicked: RadioButton = dialogView.findViewById(checkedId)
                ans = radioClicked.text.trim().toString()
            }

            submitBtn.setOnClickListener {
                if (testId.text.isNotEmpty() && questionTxt.text.isNotEmpty() && optionA.text.isNotEmpty() && optionB.text.isNotEmpty() && optionC.text.isNotEmpty() && optionD.text.isNotEmpty()) {
                    val db = DbQuestionTable(this, null)
                    db.addQuestion(
                        testId.text.toString(),
                        questionTxt.text.toString(),
                        optionA.text.toString(),
                        optionB.text.toString(),
                        optionC.text.toString(),
                        optionD.text.toString(),
                        ans
                    )
                    Toast.makeText(this, "Added, Refresh the page.", Toast.LENGTH_SHORT).show()
                    alertDialog.dismiss()
                }
            }
            cancelBtn.setOnClickListener {
                alertDialog.dismiss()
            }

            alertDialog.show()
        }
        reviewDeleteBtn.setOnClickListener {

            val dialogBuilder = android.app.AlertDialog.Builder(this)
            val dialogView = View.inflate(this, R.layout.ask_testid, null)
            val testId = dialogView.findViewById<EditText>(R.id.testId)
            val submitBtn = dialogView.findViewById<Button>(R.id.submitBtn)
            val cancelBtn = dialogView.findViewById<Button>(R.id.cancelBtn)

            val alertDialog = dialogBuilder.setView(dialogView).create()
            alertDialog.setCancelable(false)

            submitBtn.setOnClickListener {
                if (testId.text.isNotEmpty()) {
                    val intent = Intent(this, ReviewDelete::class.java)
                    intent.putExtra("testId", testId.text.toString())
                    startActivity(intent)
                    alertDialog.dismiss()
                }
            }
            cancelBtn.setOnClickListener {
                alertDialog.dismiss()
            }
            alertDialog.show()
        }
        editQuestionBtn.setOnClickListener {

            val dialogBuilder = android.app.AlertDialog.Builder(this)
            val dialogView = View.inflate(this, R.layout.edit_question, null)

            val askId: LinearLayout = dialogView.findViewById(R.id.ask_id)
            val questionEditable: LinearLayout = dialogView.findViewById(R.id.question_editable)

            val questionId = dialogView.findViewById<EditText>(R.id.testId)
            val submitBtn = dialogView.findViewById<Button>(R.id.submitBtn)
            val cancelBtn = dialogView.findViewById<Button>(R.id.cancelBtn)

            val questionTxt_editable: EditText = dialogView.findViewById(R.id.questionTxt_editable)
            val questionId_editable: TextView = dialogView.findViewById(R.id.question_id_editable)
            val optionA_editable: EditText = dialogView.findViewById(R.id.optionA_editable)
            val optionB_editable: EditText = dialogView.findViewById(R.id.optionB_editable)
            val optionC_editable: EditText = dialogView.findViewById(R.id.optionC_editable)
            val optionD_editable: EditText = dialogView.findViewById(R.id.optionD_editable)
            val ansTxt_editable: EditText = dialogView.findViewById(R.id.ansTxt_editable)
            val updateBtn: Button = dialogView.findViewById(R.id.updateBtn)

            val alertDialog = dialogBuilder.setView(dialogView).create()
            alertDialog.setCancelable(false)

            questionEditable.visibility = View.GONE

            submitBtn.setOnClickListener {
                if (questionId.text.isNotEmpty()) {
                    var list: ArrayList<String> = ArrayList()
                    val db2 = DbQuestionTable(this, null)
                    list = db2.getParticularQuestion(questionId.text.toString())

                    questionId_editable.text =
                        questionId_editable.text.toString() + questionId.text.toString()
                    questionTxt_editable.setText(list[0])
                    optionA_editable.setText(list[1])
                    optionB_editable.setText(list[2])
                    optionC_editable.setText(list[3])
                    optionD_editable.setText(list[4])
                    ansTxt_editable.setText(list[5])

                    askId.visibility = View.GONE
                    questionEditable.visibility = View.VISIBLE
                }
            }
            cancelBtn.setOnClickListener {
                alertDialog.dismiss()
            }

            updateBtn.setOnClickListener {
                val dialogBuilder2 = android.app.AlertDialog.Builder(this)
                val dialogView2 = View.inflate(this, R.layout.update_alert, null)
                val yesBtn = dialogView2.findViewById<Button>(R.id.submitBtn)
                val noBtn = dialogView2.findViewById<Button>(R.id.cancelBtn)

                val alertDialog2 = dialogBuilder2.setView(dialogView2).create()
                alertDialog2.setCancelable(false)

                yesBtn.setOnClickListener {
                    val str = ansTxt_editable.text.trim().toString().lowercase()
                    if (questionTxt_editable.text.isNotEmpty() && optionA_editable.text.isNotEmpty() && optionB_editable.text.isNotEmpty() && optionC_editable.text.isNotEmpty() && optionD_editable.text.isNotEmpty() && ansTxt_editable.text.isNotEmpty() && (str == "a" || str == "b" || str == "c" || str == "d")) {
                        val db = DbQuestionTable(this, null)
                        db.updateQuestion(
                            questionId.text.toString(),
                            questionTxt_editable.text.toString(),
                            optionA_editable.text.toString(),
                            optionB_editable.text.toString(),
                            optionC_editable.text.toString(),
                            optionD_editable.text.toString(),
                            ansTxt_editable.text.toString()
                        )
                        Toast.makeText(this, "updated", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "enter ans correctly", Toast.LENGTH_SHORT).show()
                    }
                    alertDialog2.dismiss()
                    alertDialog.dismiss()
                }
                noBtn.setOnClickListener {
                    alertDialog2.dismiss()
                }
                alertDialog2.show()
            }
            alertDialog.show()
        }
        deleteTestBtn.setOnClickListener {
            val dialogBuilder = android.app.AlertDialog.Builder(this)
            val dialogView = View.inflate(this, R.layout.ask_testid, null)
            val testId = dialogView.findViewById<EditText>(R.id.testId)
            val submitBtn = dialogView.findViewById<Button>(R.id.submitBtn)
            val cancelBtn = dialogView.findViewById<Button>(R.id.cancelBtn)

            val alertDialog = dialogBuilder.setView(dialogView).create()
            alertDialog.setCancelable(false)

            submitBtn.setOnClickListener {
                if (testId.text.isNotEmpty()) {
                    val dialogBuilder2 = android.app.AlertDialog.Builder(this)
                    val dialogView2 = View.inflate(this, R.layout.update_alert, null)
                    val yesBtn = dialogView2.findViewById<Button>(R.id.submitBtn)
                    val noBtn = dialogView2.findViewById<Button>(R.id.cancelBtn)

                    val alertDialog2 = dialogBuilder2.setView(dialogView2).create()
                    alertDialog2.setCancelable(false)

                    yesBtn.setOnClickListener {
                        val db2 = DbTest(this, null)
                        db2.deleteTest(testId.text.toString())
                        alertDialog2.dismiss()
                        alertDialog.dismiss()
                        Toast.makeText(this, "Deleted, refresh your page", Toast.LENGTH_SHORT).show()
                    }
                    noBtn.setOnClickListener {
                        alertDialog2.dismiss()
                    }
                    alertDialog2.show()
                }
            }
            cancelBtn.setOnClickListener {
                alertDialog.dismiss()
            }
            alertDialog.show()
        }
        searchBox.setOnQueryTextListener(object :
            androidx.appcompat.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                adapter.filter.filter(newText)
                return true
            }
        })
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            true
        } else super.onOptionsItemSelected(item)
    }

    private fun calculateDesiredHeight(listView: ListView): Int {
        val adapter = listView.adapter
        var totalHeight = 0
        val itemCount = adapter.count
        if (itemCount > 0) {
            val listItem = adapter.getView(0, null, listView)
            listItem.measure(
                View.MeasureSpec.UNSPECIFIED,
                View.MeasureSpec.UNSPECIFIED
            )
            totalHeight = listItem.measuredHeight * itemCount
            totalHeight += (listView.dividerHeight * (itemCount - 1))
        }
        return totalHeight
    }

    private fun getCurrentDate(): String {
        val calendar = Calendar.getInstance()
        val dateFormat = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
        return dateFormat.format(calendar.time)
    }

    override fun onBackPressed() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Logout !")
        builder.setMessage(
            "Are you sure to Logout ?"
        )
        builder.setPositiveButton("Logout") { dialog, which ->
            super.onBackPressed()
        }
        builder.setNegativeButton("Cancel") { dialog, which ->
        }
        builder.setCancelable(true)
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }
}