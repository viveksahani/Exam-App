package com.example.examapp

class TestModel(
    val testId: String,
    val testName: String,
    val testDate: String,
    val isNegative: String,
    val noOfQuestions: String
) {
}