package com.example.examapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView

class ReviewDelete : AppCompatActivity() {
    lateinit var listReviewDelete: ListView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_review_delete)

        listReviewDelete = findViewById(R.id.list_review_delete)
        var list: MutableList<QuestionModel>
        val testId = intent.getStringExtra("testId").toString()

        val db = DbQuestionTable(this, null)
        list = db.getAllQuestions(testId)

        var adapter = AdapterClassReviewDelete(this, R.layout.test_review, list)
        listReviewDelete.adapter = adapter
        adapter.notifyDataSetChanged()
    }
}