package com.example.examapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class LoginTeacher : AppCompatActivity() {
    lateinit var id: EditText
    lateinit var password: EditText
    lateinit var login_btn: Button
    lateinit var register_btn: TextView
    lateinit var forgot_btn: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_teacher)
        id = findViewById(R.id.teacherId)
        password = findViewById(R.id.teacherPassword)
        login_btn = findViewById(R.id.login_btn_teacher)
        register_btn = findViewById(R.id.register)
        forgot_btn = findViewById(R.id.forgotPassword)



        id.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {
                if (id.text.length != 5) {
                    id.error = "enter valid userId of length 5"
                } else {
                    val temp = DbTeacher(this, null)
                    if (temp.gatValidUserId(id.text.toString())) {
                        id.error = "this id not registered yet"
                    } else {
                        id.error = null
                    }
                }
            }
        }
        password.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {
                if (password.text.isEmpty()) {
                    password.error = "enter password"
                } else {
                    password.error = null
                }
            }
        }

        login_btn.setOnClickListener {
            if (verify()) {
                val pass = getPassword()
                if (password.text.toString() == pass) {
                    password.error = null
                    val intent = Intent(this, ProfileTeacher::class.java)
                    intent.putExtra("id", id.text.toString())
                    startActivity(intent)
                    finish()
                } else {
                    password.error = "incorrect password"
                }
            }
        }
        register_btn.setOnClickListener {
            val intent = Intent(this, RegisterTeacher::class.java)
            startActivity(intent)
        }
        forgot_btn.setOnClickListener {
            val intent = Intent(this, ForgotPassword::class.java)
            startActivity(intent)
        }
    }

    private fun verify(): Boolean {
        var flg1 = true
        var flg2 = true
        if (id.text.length != 5) {
            id.error = "enter valid userId"
            flg1 = false
        } else {
            val temp = DbTeacher(this, null)
            if (temp.gatValidUserId(id.text.toString())) {
                id.error = "this id not registered yet"
                flg1 = false
            } else {
                id.error = null
                flg1 = true
            }
        }
        if (password.text.isBlank()) {
            password.error = "enter password"
            flg2 = false
        } else {
            password.error = null
            flg2 = true
        }
        return (flg1 && flg2)
    }

    private fun getPassword(): String {
        val temp = DbTeacher(this, null)
        return temp.getTeacherPassword(id.text.toString()).toString()
    }
}