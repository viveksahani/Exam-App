package com.example.examapp

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DbAll(var context: Context, factory: SQLiteDatabase.CursorFactory?) :
    SQLiteOpenHelper(context, DATABASE_NAME, factory, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "ExamApp"
        private const val DATABASE_VERSION = 9
    }

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL(AdminTable.CREATE_TABLE)
        db?.execSQL(PendingAdmin.CREATE_TABLE)
        db?.execSQL(PendingStudent.CREATE_TABLE)
        db?.execSQL(PendingTeacher.CREATE_TABLE)
        db?.execSQL(StudentTable.CREATE_TABLE)
        db?.execSQL(TeacherTable.CREATE_TABLE)
        db?.execSQL(TestTable.CREATE_TABLE)
        db?.execSQL(QuestionTable.CREATE_TABLE)
        db?.execSQL(AttemptedTestTable.CREATE_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {
        db?.execSQL("DROP TABLE IF EXISTS ${AdminTable.TABLE_NAME}")
        db?.execSQL("DROP TABLE IF EXISTS ${PendingAdmin.TABLE_NAME}")
        db?.execSQL("DROP TABLE IF EXISTS ${PendingStudent.TABLE_NAME}")
        db?.execSQL("DROP TABLE IF EXISTS ${PendingTeacher.TABLE_NAME}")
        db?.execSQL("DROP TABLE IF EXISTS ${StudentTable.TABLE_NAME}")
        db?.execSQL("DROP TABLE IF EXISTS ${TeacherTable.TABLE_NAME}")
        db?.execSQL("DROP TABLE IF EXISTS ${TestTable.TABLE_NAME}")
        db?.execSQL("DROP TABLE IF EXISTS ${QuestionTable.TABLE_NAME}")
        db?.execSQL("DROP TABLE IF EXISTS ${AttemptedTestTable.TABLE_NAME}")

        onCreate(db)
    }
    object AdminTable {
        const val TABLE_NAME = "AdminTable"
        const val COL_ID = "userId"
        const val COL_NAME = "name"
        const val COL_DOB = "dob"
        const val COL_PASSWORD = "password"

        const val CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " (" + COL_ID + " INTEGER PRIMARY KEY, " + COL_NAME + " TEXT, " + COL_DOB + " TEXT, " + COL_PASSWORD + " TEXT" + ")"
    }
    object PendingAdmin {
        const val TABLE_NAME = "PendingAdmin"
        const val COL_ID = "userId"
        const val COL_NAME = "name"
        const val COL_DOB = "dob"
        const val COL_PASSWORD = "password"

        const val CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " (" + COL_ID + " INTEGER PRIMARY KEY, " + COL_NAME + " TEXT, " + COL_DOB + " TEXT, " + COL_PASSWORD + " TEXT" + ")"
    }
    object PendingStudent {
        const val TABLE_NAME = "PendingStudent"
        const val COL_ID = "UserId"
        const val COL_NAME = "name"
        const val COL_DOB = "dob"
        const val COL_PASSWORD = "password"
        const val COL_RATING = "rating"

        const val CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " (" + COL_ID + " INTEGER PRIMARY KEY, " + COL_NAME + " TEXT, " + COL_DOB + " TEXT, " + COL_PASSWORD + " TEXT, " + COL_RATING + " FLOAT" + ")"
    }
    object PendingTeacher {
        const val TABLE_NAME = "PendingTeacher"
        const val COL_ID = "UserId"
        const val COL_NAME = "name"
        const val COL_DOB = "dob"
        const val COL_PASSWORD = "password"

        const val CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " (" + COL_ID + " INTEGER PRIMARY KEY, " + COL_NAME + " TEXT, " + COL_DOB + " TEXT, " + COL_PASSWORD + " TEXT" + ")"
    }
    object StudentTable {
        const val TABLE_NAME = "StudentTable"
        const val COL_ID = "userId"
        const val COL_NAME = "name"
        const val COL_DOB = "dob"
        const val COL_PASSWORD = "password"
        const val COL_RATING = "rating"

        const val CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " (" + COL_ID + " INTEGER PRIMARY KEY, " + COL_NAME + " TEXT, " + COL_DOB + " TEXT, " + COL_PASSWORD + " TEXT, " + COL_RATING + " FLOAT" + ")"
    }
    object TeacherTable {
        const val TABLE_NAME = "TeacherTable"
        const val COL_ID = "userId"
        const val COL_NAME = "name"
        const val COL_DOB = "dob"
        const val COL_PASSWORD = "password"

        const val CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " (" + COL_ID + " INTEGER PRIMARY KEY, " + COL_NAME + " TEXT, " + COL_DOB + " TEXT, " + COL_PASSWORD + " TEXT" + ")"
    }
    object TestTable {
        const val TABLE_NAME = "TestTable"
        const val COL_TEST_ID = "testId"
        const val COL_TEACHER_ID = "teacherId"
        const val COL_TEST_NAME = "testName"
        const val COL_DATE = "testDate"
        const val COL_NEGATIVE = "negativeMarking"

        const val CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " (" + COL_TEST_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COL_TEACHER_ID + " INTEGER, " + COL_TEST_NAME + " TEXT, " + COL_DATE + " TEXT, " + COL_NEGATIVE + " TEXT" + ");"
    }
    object QuestionTable {
        const val TABLE_NAME = "QuestionTable"
        const val COL_QUESTION_ID = "questionId"
        const val COL_TEST_ID = "testId"
        const val COL_QUESTION_TEXT = "question"
        const val COL_OPTION_A = "optionA"
        const val COL_OPTION_B = "optionB"
        const val COL_OPTION_C = "optionC"
        const val COL_OPTION_D = "optionD"
        const val COL_ANSWER = "answer"

        const val CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " (" + COL_QUESTION_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COL_TEST_ID + " INTEGER, " + COL_QUESTION_TEXT + " TEXT, " + COL_OPTION_A + " TEXT, " + COL_OPTION_B + " TEXT, " + COL_OPTION_C + " TEXT, " + COL_OPTION_D + " TEXT, " + COL_ANSWER + " TEXT" + ");"
    }
    object AttemptedTestTable {
        const val TABLE_NAME = "AttemptedTestTable"
        const val COL_RESULT_ID = "resultId"
        const val COL_STUDENT_ID = "studentId"
        const val COL_TEST_ID = "testId"
        const val COL_TEST_NAME = "testName"
        const val COL_TOTAL_MARKS = "totalMarks"
        const val COL_OBTAINED_MARKS = "obtainedMarks"

        const val CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " (" + COL_RESULT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COL_STUDENT_ID + " INTEGER, " + COL_TEST_ID + " INTEGER, " + COL_TEST_NAME + " TEXT, " + COL_TOTAL_MARKS + " TEXT, " + COL_OBTAINED_MARKS + " TEXT);"
    }
}