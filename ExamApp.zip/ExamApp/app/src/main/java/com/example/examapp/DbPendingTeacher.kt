package com.example.examapp

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteDatabase.CursorFactory
import android.database.sqlite.SQLiteOpenHelper

class DbPendingTeacher(context: Context, factory: SQLiteDatabase.CursorFactory?) :
    SQLiteOpenHelper(context, DATABASE_NAME, factory, DATABASE_VERSION) {
    private var isTableCreated = false
    companion object {
        const val DATABASE_NAME = "ExamApp"
        const val DATABASE_VERSION = 9
        const val TABLE_NAME = "PendingTeacher"
        const val COL_ID = "UserId"
        const val COL_NAME = "name"
        const val COL_DOB = "dob"
        const val COL_PASSWORD = "password"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        if(!isTableCreated) {
            val query =
                ("CREATE TABLE $TABLE_NAME ($COL_ID INTEGER PRIMARY KEY, $COL_NAME TEXT, $COL_DOB TEXT, $COL_PASSWORD TEXT)")
            db?.execSQL(query)
        }
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun addPendingTeacher(id: String, name: String, dob: String, password: String) {
        val values = ContentValues()
        values.put(COL_ID, id)
        values.put(COL_NAME, name)
        values.put(COL_DOB, dob)
        values.put(COL_PASSWORD, password)
        val db = this.writableDatabase
        db.insert(TABLE_NAME, null, values)
        db.close()
    }
    fun gatValidUserId(user: String): Boolean {
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_NAME WHERE $COL_ID = ?", arrayOf(user))
        if (cursor.moveToFirst()) {
            cursor.close()
            db.close()
            return false
        }
        cursor.close()
        db.close()
        return true
    }
    fun deleteUser(user: String): Boolean {
        val db = this.writableDatabase
        val whereClause = "$COL_ID = ?"
        val whereArgs = arrayOf(user)
        val rowsDeleted = db.delete(TABLE_NAME, whereClause, whereArgs)
        db.close()
        return rowsDeleted > 0
    }
    fun getAllPendingTeacher(): MutableList<PendingModelClass> {
        val list = mutableListOf<PendingModelClass>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null)
        cursor?.moveToFirst()
        while (!cursor?.isAfterLast!!) {
            var index = cursor.getColumnIndex("UserId")
            val userId = cursor.getString(index)
            index = cursor.getColumnIndex("name")
            val name = cursor.getString(index)
            index = cursor.getColumnIndex("dob")
            val dob = cursor.getString(index)
            index = cursor.getColumnIndex("password")
            val password = cursor.getString(index)
            list.add(PendingModelClass(userId, name, dob, password))
            cursor.moveToNext()
        }
        db.close()
        return list
    }
}