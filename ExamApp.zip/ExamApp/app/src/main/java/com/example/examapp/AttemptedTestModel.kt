package com.example.examapp

class AttemptedTestModel(
    val testId: String,
    val testName: String,
    val maximumMarks: String,
    val marksObtained: String,
    val isNegative: String,
    val noOfQuestions: String
) {
}