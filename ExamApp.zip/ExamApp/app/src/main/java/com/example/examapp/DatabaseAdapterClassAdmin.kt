package com.example.examapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

class DatabaseAdapterClassAdmin(
    context: Context,
    var resource: Int,
    var objects: MutableList<PendingModelClass>
) : ArrayAdapter<PendingModelClass>(context, resource, objects) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val layoutInflater: LayoutInflater = LayoutInflater.from(context)
        val view: View = layoutInflater.inflate(resource, null)
        val idTxt: TextView = view.findViewById(R.id.userId)
        val name: TextView = view.findViewById(R.id.name)
        val dob: TextView = view.findViewById(R.id.dob)
        val profileBtn: Button = view.findViewById(R.id.profileBtn)
        val deleteBtn: Button = view.findViewById(R.id.deleteBtn)
        val mItem: PendingModelClass = objects[position]
        idTxt.text = mItem.id
        name.text = mItem.name
        dob.text = mItem.dob
        profileBtn.tag = position
        deleteBtn.tag = position
        profileBtn.setOnClickListener {
            Toast.makeText(context, "That is all", Toast.LENGTH_SHORT).show()
        }
        deleteBtn.setOnClickListener {
            val builder = AlertDialog.Builder(context)
            builder.setTitle("Deletion Alert!")
            builder.setMessage(
                "Confirm to delete selected Admin ?"
            )
            builder.setPositiveButton("Yes") { dialog, which ->
                val temp = DbAdmin(context, null)
                if (temp.deleteAdmin(mItem.id)) {
                    var item_delete = objects.get(it.tag as Int)
                    objects.remove(item_delete)
                }
                notifyDataSetChanged()
            }
            builder.setNegativeButton("No") { dialog, which ->
            }
            builder.setCancelable(true)
            val dialog: AlertDialog = builder.create()
            dialog.show()
        }
        return view
    }
}