package com.example.examapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import android.window.OnBackInvokedDispatcher
import java.util.ArrayList

class GiveTest : AppCompatActivity() {
    lateinit var userId: String
    lateinit var testId: String
    lateinit var listGiveTest: ListView
    lateinit var testNameTxt: TextView
    lateinit var negativeMarking: TextView
    lateinit var testIdTxt: TextView
    lateinit var submitBtn: ImageView
    lateinit var list: MutableList<GiveTestModel>
    lateinit var isNegative: String
    lateinit var testName: String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_give_test)

        testNameTxt = findViewById(R.id.test_name)
        negativeMarking = findViewById(R.id.negative_marking)
        testIdTxt = findViewById(R.id.test_id)
        submitBtn = findViewById(R.id.submit_btn)
        userId = intent.getStringExtra("userId").toString()
        testId = intent.getStringExtra("testId").toString()
        listGiveTest = findViewById(R.id.list_give_test)

        val db = DbTest(this, null)
        testName = db.getTestName(testId)
        isNegative = db.isNegative(testId)
        testNameTxt.text = testName
        negativeMarking.text = "Negative Marking: " + isNegative
        testIdTxt.text = "Test ID: " + testId


        val db2 = DbQuestionTable(this, null)
        list = db2.getAllQuestionsForTest(testId)
        var adapter = AdapterClassGiveTest(this, R.layout.give_test_mcq, list)
        listGiveTest.adapter = adapter
        var desiredHeight = calculateDesiredHeight(listGiveTest)
        var params = listGiveTest.layoutParams
        params.height = desiredHeight
        listGiveTest.layoutParams = params
        listGiveTest.requestLayout()

        submitBtn.setOnClickListener {

            val dialogBuilder = android.app.AlertDialog.Builder(this)
            val dialogView = View.inflate(this, R.layout.submission_alert, null)
            val submitBtn = dialogView.findViewById<Button>(R.id.submitBtn)
            val cancelBtn = dialogView.findViewById<Button>(R.id.cancelBtn)

            val alertDialog = dialogBuilder.setView(dialogView).create()
            alertDialog.setCancelable(false)

            submitBtn.setOnClickListener {
                val trueValuesList = list.filter { it.check }
                val numberOfTrueValues = trueValuesList.count { it.check }
                Toast.makeText(this, "$numberOfTrueValues", Toast.LENGTH_SHORT).show()
                val totalMarks = list.size
                var marksObtained: Double
                if (isNegative == "Yes") {
                    val x = totalMarks - ((totalMarks - numberOfTrueValues) * 0.25)
                    marksObtained = x
                } else {
                    marksObtained = numberOfTrueValues.toDouble()
                }
                alertDialog.dismiss()
                val temp = DbAttempedTest(this, null)
                if (temp.isAttempted(userId, testId)) {
                    temp.updateMarksObtained(
                        userId,
                        testId,
                        totalMarks.toString(),
                        marksObtained.toString()
                    )
                } else {
                    temp.addAttemptedTest(
                        userId,
                        testId,
                        testName,
                        totalMarks.toString(),
                        marksObtained.toString()
                    )
                }
                super.onBackPressed()
            }
            cancelBtn.setOnClickListener {
                alertDialog.dismiss()
            }
            alertDialog.show()
        }
    }

    override fun onBackPressed() {
        val dialogBuilder = android.app.AlertDialog.Builder(this)
        val dialogView = View.inflate(this, R.layout.submission_alert, null)
        val submitBtn = dialogView.findViewById<Button>(R.id.submitBtn)
        val cancelBtn = dialogView.findViewById<Button>(R.id.cancelBtn)

        val alertDialog = dialogBuilder.setView(dialogView).create()
        alertDialog.setCancelable(false)

        submitBtn.setOnClickListener {
            val trueValuesList = list.filter { it.check }
            val numberOfTrueValues = trueValuesList.count { it.check }
            Toast.makeText(this, "$numberOfTrueValues", Toast.LENGTH_SHORT).show()
            val totalMarks = list.size
            var marksObtained: Double
            if (isNegative == "Yes") {
                val x = totalMarks - ((totalMarks - numberOfTrueValues) * 0.25)
                marksObtained = x
            } else {
                marksObtained = numberOfTrueValues.toDouble()
            }
            alertDialog.dismiss()
            val temp = DbAttempedTest(this, null)
            if (temp.isAttempted(userId, testId)) {
                temp.updateMarksObtained(
                    userId,
                    testId,
                    totalMarks.toString(),
                    marksObtained.toString()
                )
            } else {
                temp.addAttemptedTest(
                    userId,
                    testId,
                    testName,
                    totalMarks.toString(),
                    marksObtained.toString()
                )
            }
            super.onBackPressed()
        }
        cancelBtn.setOnClickListener {
            alertDialog.dismiss()
        }
        alertDialog.show()
    }
    private fun calculateDesiredHeight(listView: ListView): Int {
        val adapter = listView.adapter
        var totalHeight = 0
        val itemCount = adapter.count
        if (itemCount > 0) {
            val listItem = adapter.getView(0, null, listView)
            listItem.measure(
                View.MeasureSpec.UNSPECIFIED,
                View.MeasureSpec.UNSPECIFIED
            )
            totalHeight = listItem.measuredHeight * itemCount
            totalHeight += (listView.dividerHeight * (itemCount - 1))
        }
        return totalHeight
    }
}