package com.example.examapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DbQuestionTable(context: Context, factory: SQLiteDatabase.CursorFactory?) :
    SQLiteOpenHelper(context, DATABASE_NAME, factory, DATABASE_VERSION) {
    companion object {
        const val DATABASE_VERSION = 9
        const val DATABASE_NAME = "ExamApp"
        const val TABLE_NAME = "QuestionTable"
        const val COL_QUESTION_ID = "questionId"
        const val COL_TEST_ID = "testId"
        const val COL_QUESTION_TEXT = "question"
        const val COL_OPTION_A = "optionA"
        const val COL_OPTION_B = "optionB"
        const val COL_OPTION_C = "optionC"
        const val COL_OPTION_D = "optionD"
        const val COL_ANSWER = "answer"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val query =
            ("CREATE TABLE " + TABLE_NAME + " (" + COL_QUESTION_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COL_TEST_ID + " INTEGER, " + COL_QUESTION_TEXT + " TEXT, " + COL_OPTION_A + " TEXT, " + COL_OPTION_B + " TEXT, " + COL_OPTION_C + " TEXT, " + COL_OPTION_D + " TEXT, " + COL_ANSWER + " TEXT" + ");")
        db?.execSQL(query)
    }

    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {
        db?.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME)
        onCreate(db)
    }

    fun addQuestion(
        testId: String,
        question: String,
        optionA: String,
        optionB: String,
        optionC: String,
        optionD: String,
        ans: String
    ) {
        val values = ContentValues()
        values.put(COL_TEST_ID, testId)
        values.put(COL_QUESTION_TEXT, question)
        values.put(COL_OPTION_A, optionA)
        values.put(COL_OPTION_B, optionB)
        values.put(COL_OPTION_C, optionC)
        values.put(COL_OPTION_D, optionD)
        values.put(COL_ANSWER, ans)
        val db = this.writableDatabase
        db.insert(TABLE_NAME, null, values)
        db.close()
    }

    fun getCountOfQuestion(testId: String): Int {
        val db = this.readableDatabase
        val cursor =
            db.rawQuery("SELECT * FROM $TABLE_NAME WHERE $COL_TEST_ID = ?", arrayOf(testId))
        var count = 0
        if (cursor.moveToFirst()) {
            while (!cursor?.isAfterLast!!) {
                count += 1
                cursor.moveToNext()
            }
        }
        cursor.close()
        db.close()
        return count
    }

    fun deleteSelectedQuestion(questionId:String) {
        val db = this.writableDatabase
        val whereClause = "$COL_QUESTION_ID = ?"
        val whereArgs = arrayOf(questionId)
        val rowsDeleted = db.delete(TABLE_NAME, whereClause, whereArgs)
        db.close()
    }

    fun updateQuestion(questionId:String, questionTxt:String, optionA:String, optionB:String, optionC:String, optionD:String, ans:String) {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(COL_QUESTION_TEXT, questionTxt)
        contentValues.put(COL_OPTION_A, optionA)
        contentValues.put(COL_OPTION_B, optionB)
        contentValues.put(COL_OPTION_C, optionC)
        contentValues.put(COL_OPTION_D, optionD)
        contentValues.put(COL_ANSWER, ans)
        db.update(TABLE_NAME, contentValues, "$COL_QUESTION_ID = ?", arrayOf(questionId))
        db.close()
    }

    fun getParticularQuestion(questionId: String): ArrayList<String> {
        val stringList: ArrayList<String> = ArrayList()

        val db = this.readableDatabase
        val cursor =
            db.rawQuery("SELECT * FROM $TABLE_NAME WHERE $COL_QUESTION_ID = ?", arrayOf(questionId))
        if(cursor.moveToFirst()) {
            var index = cursor.getColumnIndex("question")
            val question = cursor.getString(index)
            stringList.add(question)

            index = cursor.getColumnIndex("optionA")
            val optionA = cursor.getString(index)
            stringList.add(optionA)

            index = cursor.getColumnIndex("optionB")
            val optionB = cursor.getString(index)
            stringList.add(optionB)

            index = cursor.getColumnIndex("optionC")
            val optionC = cursor.getString(index)
            stringList.add(optionC)

            index = cursor.getColumnIndex("optionD")
            val optionD = cursor.getString(index)
            stringList.add(optionD)

            index = cursor.getColumnIndex("answer")
            val answer = cursor.getString(index)
            stringList.add(answer)
        }
        else {
            stringList.add("")
            stringList.add("")
            stringList.add("")
            stringList.add("")
            stringList.add("")
            stringList.add("")
        }
        return stringList
    }
    fun getAllQuestions(testId: String): MutableList<QuestionModel> {
        val list = mutableListOf<QuestionModel>()
        val db = this.readableDatabase
        val cursor =
            db.rawQuery("SELECT * FROM $TABLE_NAME WHERE $COL_TEST_ID = ?", arrayOf(testId))
        cursor?.moveToFirst()
        while (!cursor?.isAfterLast!!) {
            var index = cursor.getColumnIndex("questionId")
            val questionId = cursor.getString(index)

            index = cursor.getColumnIndex("question")
            val question = cursor.getString(index)

            index = cursor.getColumnIndex("optionA")
            val optionA = cursor.getString(index)

            index = cursor.getColumnIndex("optionB")
            val optionB = cursor.getString(index)

            index = cursor.getColumnIndex("optionC")
            val optionC = cursor.getString(index)

            index = cursor.getColumnIndex("optionD")
            val optionD = cursor.getString(index)

            index = cursor.getColumnIndex("answer")
            val answer = cursor.getString(index)

            list.add(
                QuestionModel(
                    questionId,
                    question,
                    optionA,
                    optionB,
                    optionC,
                    optionD,
                    answer
                )
            )
            cursor.moveToNext()
        }
        cursor.close()
        db.close()
        return list
    }
    fun getAllQuestionsForTest(testId: String): MutableList<GiveTestModel> {
        val list = mutableListOf<GiveTestModel>()
        val db = this.readableDatabase
        val cursor =
            db.rawQuery("SELECT * FROM $TABLE_NAME WHERE $COL_TEST_ID = ?", arrayOf(testId))
        cursor?.moveToFirst()
        while (!cursor?.isAfterLast!!) {
            var index = cursor.getColumnIndex("questionId")
            val questionId = cursor.getString(index)

            index = cursor.getColumnIndex("question")
            val question = cursor.getString(index)

            index = cursor.getColumnIndex("optionA")
            val optionA = cursor.getString(index)

            index = cursor.getColumnIndex("optionB")
            val optionB = cursor.getString(index)

            index = cursor.getColumnIndex("optionC")
            val optionC = cursor.getString(index)

            index = cursor.getColumnIndex("optionD")
            val optionD = cursor.getString(index)

            index = cursor.getColumnIndex("answer")
            val answer = cursor.getString(index)

            list.add(
                GiveTestModel(
                    questionId,
                    question,
                    optionA,
                    optionB,
                    optionC,
                    optionD,
                    answer,
                    false
                )
            )
            cursor.moveToNext()
        }
        cursor.close()
        db.close()
        return list
    }
}