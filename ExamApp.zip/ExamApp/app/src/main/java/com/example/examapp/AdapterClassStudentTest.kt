package com.example.examapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.TextView

class AdapterClassStudentTest(
    context: Context,
    var resource: Int,
    var objects: MutableList<TestModel>
) : ArrayAdapter<TestModel>(context, resource, objects) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val layoutInflater: LayoutInflater = LayoutInflater.from(context)
        val view: View = layoutInflater.inflate(resource, null)
        val testId: TextView = view.findViewById(R.id.testId)
        val testName: TextView = view.findViewById(R.id.testNm)
        val testDate: TextView = view.findViewById(R.id.testDate)
        val isNegative: TextView = view.findViewById(R.id.isNegative)
        val noOfQuestions: TextView = view.findViewById(R.id.noOfQus)
        val maxMarks: TextView = view.findViewById(R.id.maxMarks)
        val mItem: TestModel = objects[position]
        val date = mItem.testDate
        testId.text = testId.text.toString() + mItem.testId
        testName.text = mItem.testName
        maxMarks.text = maxMarks.text.toString() + mItem.noOfQuestions
        testDate.text = testDate.text.toString() + date
        isNegative.text = isNegative.text.toString() + mItem.isNegative
        noOfQuestions.text = noOfQuestions.text.toString() + mItem.noOfQuestions
        return view
    }
}