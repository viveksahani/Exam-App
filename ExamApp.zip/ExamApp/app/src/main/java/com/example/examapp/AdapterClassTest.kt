package com.example.examapp

import android.app.AlertDialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*

class AdapterClassTest(
    context: Context,
    var resource: Int,
    var objects: MutableList<TestModel>
) : ArrayAdapter<TestModel>(context, resource, objects) {
    private var originalData: List<TestModel> = objects.toList()
    private var filteredData: MutableList<TestModel> = objects.toMutableList()
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val layoutInflater: LayoutInflater = LayoutInflater.from(context)
        val view: View = layoutInflater.inflate(resource, null)
        val testId: TextView = view.findViewById(R.id.testId)
        val addQusBtn: TextView = view.findViewById(R.id.addQusBtn)
        val testName: TextView = view.findViewById(R.id.testNm)
        val testDate: TextView = view.findViewById(R.id.testDate)
        val isNegative: TextView = view.findViewById(R.id.isNegative)
        val noOfQuestions: TextView = view.findViewById(R.id.noOfQus)
        val maxMarks: TextView = view.findViewById(R.id.maxMarks)
        val TestBtn: LinearLayout = view.findViewById(R.id.testBtn)
        val mItem: TestModel = objects[position]
        val date = mItem.testDate
        val testid = mItem.testId
        testId.text = testId.text.toString() + mItem.testId
        testName.text = mItem.testName
        maxMarks.text = maxMarks.text.toString() + mItem.noOfQuestions
        testDate.text = testDate.text.toString() + date
        isNegative.text = isNegative.text.toString() + mItem.isNegative
        noOfQuestions.text = noOfQuestions.text.toString() + mItem.noOfQuestions

        TestBtn.setOnClickListener {
            // will implement later/ no need to implement
        }

        addQusBtn.setOnClickListener {
            val dialogBuilder = AlertDialog.Builder(context)
            val dialogView = View.inflate(context, R.layout.add_question, null)

            val questionTxt = dialogView.findViewById<EditText>(R.id.questionTxt)
            val optionA = dialogView.findViewById<EditText>(R.id.optionA)
            val optionB = dialogView.findViewById<EditText>(R.id.optionB)
            val optionC = dialogView.findViewById<EditText>(R.id.optionC)
            val optionD = dialogView.findViewById<EditText>(R.id.optionD)
            val radioAns = dialogView.findViewById<RadioGroup>(R.id.ans)
            val submitBtn = dialogView.findViewById<Button>(R.id.submitBtn)
            val cancelBtn = dialogView.findViewById<Button>(R.id.cancelBtn)

            val alertDialog = dialogBuilder.setView(dialogView).create()
            alertDialog.setCancelable(false)

            var ans = ""
            radioAns.setOnCheckedChangeListener { group, checkedId ->
                val radioClicked: RadioButton = dialogView.findViewById(checkedId)
                ans = radioClicked.text.trim().toString()
            }

            submitBtn.setOnClickListener {
                if (questionTxt.text.isNotEmpty() && optionA.text.isNotEmpty() && optionB.text.isNotEmpty() && optionC.text.isNotEmpty() && optionD.text.isNotEmpty()) {
                    val db = DbQuestionTable(context, null)
                    db.addQuestion(
                        testid,
                        questionTxt.text.toString(),
                        optionA.text.toString(),
                        optionB.text.toString(),
                        optionC.text.toString(),
                        optionD.text.toString(),
                        ans
                    )
                    Toast.makeText(context, "submitted", Toast.LENGTH_SHORT).show()
                    alertDialog.dismiss()
                }
            }
            cancelBtn.setOnClickListener {
                alertDialog.dismiss()
            }

            alertDialog.show()
        }

        return view
    }

    override fun getCount(): Int {
        return filteredData.size
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val results = FilterResults()
                if (constraint.isNullOrBlank()) {
                    results.values = originalData
                } else {
                    val filteredList = mutableListOf<TestModel>()
                    val filterPattern = constraint.toString()
                    for (item in originalData) {
                        if (item.testName.contains(filterPattern)) {
                            filteredList.add(item)
                        }
                    }
                    results.values = filteredList
                }
                return results
            }

            @Suppress("UNCHECKED_CAST")
            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                filteredData.clear()
                filteredData.addAll(results?.values as List<TestModel>)
                notifyDataSetChanged()
            }
        }
    }
}