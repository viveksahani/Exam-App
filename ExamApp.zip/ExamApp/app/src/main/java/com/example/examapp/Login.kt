package com.example.examapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout

class Login : AppCompatActivity() {
    lateinit var teacher_btn: LinearLayout
    lateinit var student_btn: LinearLayout
    lateinit var admin_btn: LinearLayout
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        teacher_btn = findViewById(R.id.teacher_btn)
        student_btn = findViewById(R.id.student_btn)
        admin_btn = findViewById(R.id.admin_btn)

        val temp1 = DbAll(this, null)
        val t = temp1.writableDatabase
        t.close()

        teacher_btn.setOnClickListener {
            val intent = Intent(this, LoginTeacher::class.java)
            startActivity(intent)
        }
        student_btn.setOnClickListener {
            val intent = Intent(this, LoginStudent::class.java)
            startActivity(intent)
        }
        admin_btn.setOnClickListener {
            val intent = Intent(this, LoginAdmin::class.java)
            startActivity(intent)
        }
    }
}