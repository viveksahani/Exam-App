package com.example.examapp

import android.app.DatePickerDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import java.util.*

class RegisterTeacher : AppCompatActivity() {
    lateinit var id: EditText
    lateinit var name:EditText
    lateinit var dob: EditText
    lateinit var calendarIcon: ImageView
    lateinit var password: EditText
    lateinit var confirm_password: EditText
    lateinit var register_btn: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_teacher)

        id = findViewById(R.id.teacherId)
        name = findViewById(R.id.teacherName)
        dob = findViewById(R.id.dob)
        calendarIcon = findViewById(R.id.calendarIcon)
        password = findViewById(R.id.password)
        confirm_password = findViewById(R.id.confirmPassword)
        register_btn = findViewById(R.id.register_btn_teacher)


        id.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {
                if (id.text.length != 5) {
                    id.error = "choose id of length 5"
                } else {
                    val temp1 = DbTeacher(this, null)
                    val temp2 = DbPendingTeacher(this, null)
                    if(temp1.gatValidUserId(id.text.toString()) && temp2.gatValidUserId(id.text.toString())) {
                        id.error = null
                    }
                    else {
                        id.error = "this id already taken"
                    }
                }
            }
        }
        name.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {
                if (name.text.isEmpty()) {
                    name.error = "enter name"
                } else {
                    name.error = null
                }
            }
        }
        dob.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {
                if (dob.text.isEmpty()) {
                    dob.error = "choose DOB"
                } else {
                    dob.error = null
                }
            }
        }
        password.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {
                if (password.text.isEmpty()) {
                    password.error = "enter strong password"
                } else {
                    password.error = null
                }
            }
        }
        confirm_password.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {
                if (confirm_password.text.toString() != password.text.toString()) {
                    confirm_password.error = "re-enter password correctly"
                } else {
                    confirm_password.error = null
                }
            }
        }

        register_btn.setOnClickListener {
            if (verify()) {
                val temp = DbPendingTeacher(this, null)
                temp.addPendingTeacher(
                    id.text.toString(),
                    name.text.toString(),
                    dob.text.toString(),
                    password.text.toString()
                )
                id.text.clear()
                name.text.clear()
                dob.text.clear()
                password.text.clear()
                confirm_password.text.clear()
                val builder = AlertDialog.Builder(this)
                builder.setTitle("Verification Under Process !")
                builder.setMessage("Your registration request has been sent to admin, you will be registered within 24hr.\nThanks to visit ExamApp. 🙂")
                builder.setPositiveButton("OK") { dialog, which ->
                    Toast.makeText(this, "🙂",Toast.LENGTH_SHORT).show()
                    onBackPressed()
                }
                builder.setCancelable(false)
                val dialog: AlertDialog = builder.create()
                dialog.show()
            }
        }
    }
    fun showDatePickerDialog(view: View) {

        val calendar = Calendar.getInstance()
        val currentYear = calendar.get(Calendar.YEAR)
        val currentMonth = calendar.get(Calendar.MONTH)
        val currentDay = calendar.get(Calendar.DAY_OF_MONTH)
        val datePickerDialog = DatePickerDialog(
            this,
            { view, year, month, dayOfMonth ->
                val selectedDate = "$dayOfMonth/${month + 1}/$year"
                dob.setText(selectedDate)
            },
            // Set initial date (optional)
            currentYear,
            currentMonth,   // (0-11)
            currentDay
        )
        datePickerDialog.show()
    }

    private fun verify(): Boolean {
        var flg1 = true
        var flg2 = true
        var flg3 = true
        var flg4 = true
        var flg5 = true
        if (id.text.length != 5) {
            id.error = "choose id of length 5"
            flg1 = false
        } else {
            val temp1 = DbTeacher(this, null)
            val temp2 = DbPendingTeacher(this, null)
            if(temp1.gatValidUserId(id.text.toString()) && temp2.gatValidUserId(id.text.toString())) {
                id.error = null
                flg1 = true
            }
            else {
                id.error = "this id already taken"
                flg1 = false
            }
        }
        if (name.text.isBlank()) {
            name.error = "enter name"
            flg2 = false
        } else {
            name.error = null
            flg2 = true
        }
        if (dob.text.isBlank()) {
            dob.error = "select DOB"
            flg3 = false
        } else {
            dob.error = null
            flg3 = true
        }
        if (password.text.isBlank()) {
            password.error = "enter strong password"
            flg4 = false
        } else {
            password.error = null
            flg4 = true
        }
        if (confirm_password.text.toString() != password.text.toString()) {
            confirm_password.error = "re-enter password correctly"
            flg5 = false
        } else {
            confirm_password.error = null
            flg5 = true
        }
        return (flg1 && flg2 && flg3 && flg4 && flg5)
    }
}