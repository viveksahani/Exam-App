package com.example.examapp

class QuestionModel(
    val questionId: String,
    val questionTxt: String,
    val optionA: String,
    val optionB: String,
    val optionC: String,
    val optionD: String,
    val ansTxt: String
) {
}