package com.example.examapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DbTest(context: Context, factory: SQLiteDatabase.CursorFactory?) :
    SQLiteOpenHelper(context, DATABASE_NAME, factory, DATABASE_VERSION) {
    val dbQuestion = DbQuestionTable(context, null)

    companion object {
        const val DATABASE_VERSION = 9
        const val DATABASE_NAME = "ExamApp"
        const val TABLE_NAME = "TestTable"
        const val COL_TEST_ID = "testId"
        const val COL_TEACHER_ID = "teacherId"
        const val COL_TEST_NAME = "testName"
        const val COL_DATE = "testDate"
        const val COL_NEGATIVE = "negativeMarking"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val query =
            ("CREATE TABLE " + TABLE_NAME + " (" + COL_TEST_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COL_TEACHER_ID + " INTEGER, " + COL_TEST_NAME + " TEXT, " + COL_DATE + " TEXT, " + COL_NEGATIVE + " TEXT" + ");")
        db?.execSQL(query)
    }

    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {
        db?.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME)
        onCreate(db)
    }

    fun addTest(user: String, testName: String, testDate: String, isNegative: String) {
        val values = ContentValues()
        values.put(COL_TEACHER_ID, user)
        values.put(COL_TEST_NAME, testName)
        values.put(COL_DATE, testDate)
        values.put(COL_NEGATIVE, isNegative)
        val db = this.writableDatabase
        db.insert(TABLE_NAME, null, values)
        db.close()
    }
    fun deleteTest(testId: String) {
        val db = this.writableDatabase
        val whereClause = "$COL_TEST_ID = ?"
        val whereArgs = arrayOf(testId)
        val rowsDeleted = db.delete(TABLE_NAME, whereClause, whereArgs)
        db.close()
    }

    fun isNegative(testId:String):String {
        var isNegative = ""
        val db = this.readableDatabase
        val cursor =
            db.rawQuery("SELECT * FROM $TABLE_NAME WHERE $COL_TEST_ID = ?", arrayOf(testId))
        if(cursor.moveToFirst()) {
            var index = cursor.getColumnIndex("negativeMarking")
            isNegative = cursor.getString(index)
        }
        return isNegative
    }
    fun getTestOfAllTeacher(): MutableList<TestModel> {
        val list = mutableListOf<TestModel>()
        val db = this.readableDatabase
        val cursor =
            db.rawQuery("SELECT * FROM $TABLE_NAME", arrayOf())
        cursor?.moveToFirst()
        while (!cursor?.isAfterLast!!) {
            var index = cursor.getColumnIndex("testId")
            val testId = cursor.getString(index)

            index = cursor.getColumnIndex("testName")
            val testName = cursor.getString(index)

            index = cursor.getColumnIndex("testDate")
            val testDate = cursor.getString(index)

            index = cursor.getColumnIndex("negativeMarking")
            val isNegative = cursor.getString(index)

            val count = dbQuestion.getCountOfQuestion(testId).toString()

            list.add(TestModel(testId, testName, testDate, isNegative, count))
            cursor.moveToNext()
        }
        cursor.close()
        db.close()
        return list
    }
    fun getAllTest(user: String): MutableList<TestModel> {
        val list = mutableListOf<TestModel>()
        val db = this.readableDatabase
        val cursor =
            db.rawQuery("SELECT * FROM $TABLE_NAME WHERE $COL_TEACHER_ID = ?", arrayOf(user))
        cursor?.moveToFirst()
        while (!cursor?.isAfterLast!!) {
            var index = cursor.getColumnIndex("testId")
            val testId = cursor.getString(index)

            index = cursor.getColumnIndex("testName")
            val testName = cursor.getString(index)

            index = cursor.getColumnIndex("testDate")
            val testDate = cursor.getString(index)

            index = cursor.getColumnIndex("negativeMarking")
            val isNegative = cursor.getString(index)

            val count = dbQuestion.getCountOfQuestion(testId).toString()

            list.add(TestModel(testId, testName, testDate, isNegative, count))
            cursor.moveToNext()
        }
        cursor.close()
        db.close()
        return list
    }
    fun getTestName(testId:String): String {
        var testName = ""
        val db = this.readableDatabase
        val cursor =
            db.rawQuery("SELECT * FROM $TABLE_NAME WHERE $COL_TEST_ID = ?", arrayOf(testId))
        if(cursor.moveToFirst()) {
            var index = cursor.getColumnIndex("testName")
            testName = cursor.getString(index)
        }
        return testName
    }
}