package com.example.examapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.core.view.GravityCompat
import androidx.core.view.isVisible
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class ProfileAdmin : AppCompatActivity() {
    lateinit var id:String
    lateinit var nav_name:TextView
    lateinit var drawerLayout: DrawerLayout
    lateinit var actionBarDrawerToggle: ActionBarDrawerToggle
    lateinit var navigationView: NavigationView
    lateinit var nav_headerView:View
    lateinit var dp:ImageView

    lateinit var pendingBtn: Button
    lateinit var pendingDropdown: LinearLayout
    lateinit var pendingStudentBtn: Button
    lateinit var pendingStudentDropdown: LinearLayout
    lateinit var pendingTeacherBtn: Button
    lateinit var pendingTeacherDropdown: LinearLayout
    lateinit var pendingAdminBtn: Button
    lateinit var pendingAdminDropdown: LinearLayout

    lateinit var databaseBtn: Button
    lateinit var databaseDropdown: LinearLayout
    lateinit var databaseStudentBtn: Button
    lateinit var databaseStudentDropdown: LinearLayout
    lateinit var databaseTeacherBtn: Button
    lateinit var databaseTeacherDropdown: LinearLayout
    lateinit var databaseAdminBtn: Button
    lateinit var databaseAdminDropdown: LinearLayout

    lateinit var pendingArrow: ImageButton
    lateinit var databaseArrow: ImageButton

    lateinit var pendingAdminList: ListView
    lateinit var pendingStudentList: ListView
    lateinit var pendingTeacherList: ListView

    lateinit var databaseAdminList: ListView
    lateinit var databaseStudentList: ListView
    lateinit var databaseTeacherList: ListView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile_admin)

        id = intent.getStringExtra("id").toString()
        drawerLayout = findViewById(R.id.drawer_layout_admin)
        actionBarDrawerToggle =
            ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close)
        drawerLayout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState()
        supportActionBar?.setDisplayHomeAsUpEnabled(true)


        navigationView = findViewById(R.id.navigationAdmin)
        nav_headerView = navigationView.getHeaderView(0)
        dp = nav_headerView.findViewById(R.id.dp)
        nav_name = nav_headerView.findViewById(R.id.navName)



        pendingBtn = findViewById(R.id.pending)
        pendingDropdown = findViewById(R.id.pendingDropdown)
        pendingStudentBtn = findViewById(R.id.pendingStudent)
        pendingStudentDropdown = findViewById(R.id.pendingStudentDropdown)
        pendingTeacherBtn = findViewById(R.id.pendingTeacher)
        pendingTeacherDropdown = findViewById(R.id.pendingTeacherDropdown)
        pendingAdminBtn = findViewById(R.id.pendingAdmin)
        pendingAdminDropdown = findViewById(R.id.pendingAdminDropdown)

        databaseBtn = findViewById(R.id.database)
        databaseDropdown = findViewById(R.id.databaseDropdown)
        databaseStudentBtn = findViewById(R.id.databaseStudent)
        databaseStudentDropdown = findViewById(R.id.databaseStudentDropdown)
        databaseTeacherBtn = findViewById(R.id.databaseTeacher)
        databaseTeacherDropdown = findViewById(R.id.databaseTeacherDropdown)
        databaseAdminBtn = findViewById(R.id.databaseAdmin)
        databaseAdminDropdown = findViewById(R.id.databaseAdminDropdown)

        pendingAdminList = findViewById(R.id.pendingAdminList)
        pendingStudentList = findViewById(R.id.pendingStudentList)
        pendingTeacherList = findViewById(R.id.pendingTeacherList)

        databaseAdminList = findViewById(R.id.databaseAdminList)
        databaseStudentList = findViewById(R.id.databaseStudentList)
        databaseTeacherList = findViewById(R.id.databaseTeacherList)
        var list = mutableListOf<PendingModelClass>()

        pendingArrow = findViewById(R.id.pendingArrow)
        databaseArrow = findViewById(R.id.databaseArrow)

        pendingDropdown.visibility = View.GONE
        databaseDropdown.visibility = View.GONE




        if(id == "00000") {
            nav_name.text = "Vivek Sahani"
            dp.background = getDrawable(R.drawable.dp)
        } else {
            val tmp = DbAdmin(this, null)
            val nm = id?.let { tmp.getAdminName(it) }
            nav_name.text = nm
        }
        navigationView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.home -> {
                    Toast.makeText(this, "Home selected", Toast.LENGTH_SHORT).show()
                }
                R.id.logout -> {
                    val builder = AlertDialog.Builder(this)
                    builder.setTitle("Logout !")
                    builder.setMessage(
                        "Are you sure to Logout ?"
                    )
                    builder.setPositiveButton("Logout") { dialog, which ->
                        onBackPressed()
                    }
                    builder.setNegativeButton("Cancel") { dialog, which ->
                    }
                    builder.setCancelable(true)
                    val dialog: AlertDialog = builder.create()
                    dialog.show()
                }
            }
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }




        pendingStudentBtn.setOnClickListener {
            pendingTeacherDropdown.visibility = View.GONE
            pendingAdminDropdown.visibility = View.GONE
            pendingStudentDropdown.visibility = View.VISIBLE
            if (pendingStudentDropdown.isVisible) {
                list.clear()
                val db = DbPendingStudent(this, null)
                list = db.getAllPendingStudent()
                pendingStudentList.adapter =
                    PendingAdapterClassStudent(this, R.layout.pending_list_model, list)

                val desiredHeight = calculateDesiredHeight(pendingStudentList)
                val params = pendingStudentList.layoutParams
                params.height = desiredHeight
                pendingStudentList.layoutParams = params
                pendingStudentList.requestLayout()
            }
        }
        pendingTeacherBtn.setOnClickListener {
            pendingAdminDropdown.visibility = View.GONE
            pendingStudentDropdown.visibility = View.GONE
            pendingTeacherDropdown.visibility = View.VISIBLE
            if (pendingTeacherDropdown.isVisible) {
                list.clear()
                val db = DbPendingTeacher(this, null)
                list = db.getAllPendingTeacher()
                pendingTeacherList.adapter =
                    PendingAdapterClassTeacher(this, R.layout.pending_list_model, list)

                val desiredHeight = calculateDesiredHeight(pendingTeacherList)
                val params = pendingTeacherList.layoutParams
                params.height = desiredHeight
                pendingTeacherList.layoutParams = params
                pendingTeacherList.requestLayout()
            }
        }
        pendingAdminBtn.setOnClickListener {
            pendingStudentDropdown.visibility = View.GONE
            pendingTeacherDropdown.visibility = View.GONE
            pendingAdminDropdown.visibility = View.VISIBLE
            if (pendingAdminDropdown.isVisible) {
                list.clear()
                val db = DbPendingAdmin(this, null)
                list = db.getAllPendingAdmin()
                pendingAdminList.adapter =
                    PendingAdapterClassAdmin(this, R.layout.pending_list_model, list)
                val desiredHeight = calculateDesiredHeight(pendingAdminList)
                val params = pendingAdminList.layoutParams
                params.height = desiredHeight
                pendingAdminList.layoutParams = params
                pendingAdminList.requestLayout()
            }
        }

        databaseStudentBtn.setOnClickListener {
            databaseTeacherDropdown.visibility = View.GONE
            databaseAdminDropdown.visibility = View.GONE
            databaseStudentDropdown.visibility = View.VISIBLE
            if (databaseStudentDropdown.isVisible) {
                list.clear()
                val db = DbStudent(this, null)
                list = db.getAllStudent()
                databaseStudentList.adapter =
                    DatabaseAdapterClassStudent(this, R.layout.database_list_model, list)
                val desiredHeight = calculateDesiredHeight(databaseStudentList)
                val params = databaseStudentList.layoutParams
                params.height = desiredHeight
                databaseStudentList.layoutParams = params
                databaseStudentList.requestLayout()
            }
        }
        databaseTeacherBtn.setOnClickListener {
            databaseAdminDropdown.visibility = View.GONE
            databaseStudentDropdown.visibility = View.GONE
            databaseTeacherDropdown.visibility = View.VISIBLE
            if (databaseTeacherDropdown.isVisible) {
                list.clear()
                val db = DbTeacher(this, null)
                list = db.getAllTeacher()
                databaseTeacherList.adapter =
                    DatabaseAdapterClassTeacher(this, R.layout.database_list_model, list)
                val desiredHeight = calculateDesiredHeight(databaseTeacherList)
                val params = databaseTeacherList.layoutParams
                params.height = desiredHeight
                databaseTeacherList.layoutParams = params
                databaseTeacherList.requestLayout()
            }
        }
        databaseAdminBtn.setOnClickListener {
            databaseStudentDropdown.visibility = View.GONE
            databaseTeacherDropdown.visibility = View.GONE
            databaseAdminDropdown.visibility = View.VISIBLE
            if (databaseAdminDropdown.isVisible) {
                list.clear()
                val db = DbAdmin(this, null)
                list = db.getAllAdmin()
                databaseAdminList.adapter =
                    DatabaseAdapterClassAdmin(this, R.layout.database_list_model, list)
                val desiredHeight = calculateDesiredHeight(databaseAdminList)
                val params = databaseAdminList.layoutParams
                params.height = desiredHeight
                databaseAdminList.layoutParams = params
                databaseAdminList.requestLayout()
            }
        }


        val commonClickListener1 = View.OnClickListener {
            pendingTeacherDropdown.visibility = View.GONE
            pendingAdminDropdown.visibility = View.GONE
            pendingStudentDropdown.visibility = View.GONE
            if (pendingDropdown.isVisible) {
                pendingDropdown.visibility = View.GONE
                pendingArrow.setImageResource(R.drawable.ic_baseline_arrow_forward_ios_24)
            } else {
                databaseTeacherDropdown.visibility = View.GONE
                databaseAdminDropdown.visibility = View.GONE
                databaseStudentDropdown.visibility = View.GONE
                databaseDropdown.visibility = View.GONE
                databaseArrow.setImageResource(R.drawable.ic_baseline_arrow_forward_ios_24)
                pendingArrow.setImageResource(R.drawable.ic_baseline_keyboard_arrow_down_24)
                pendingDropdown.visibility = View.VISIBLE
            }
        }
        pendingBtn.setOnClickListener(commonClickListener1)
        pendingArrow.setOnClickListener(commonClickListener1)

        val commonClickListener2 = View.OnClickListener {
            if (databaseDropdown.isVisible) {
                databaseTeacherDropdown.visibility = View.GONE
                databaseAdminDropdown.visibility = View.GONE
                databaseStudentDropdown.visibility = View.GONE
                databaseDropdown.visibility = View.GONE
                databaseArrow.setImageResource(R.drawable.ic_baseline_arrow_forward_ios_24)
            } else {
                pendingTeacherDropdown.visibility = View.GONE
                pendingAdminDropdown.visibility = View.GONE
                pendingStudentDropdown.visibility = View.GONE
                pendingArrow.setImageResource(R.drawable.ic_baseline_arrow_forward_ios_24)
                pendingDropdown.visibility = View.GONE
                databaseArrow.setImageResource(R.drawable.ic_baseline_keyboard_arrow_down_24)
                databaseDropdown.visibility = View.VISIBLE
            }
        }
        databaseBtn.setOnClickListener(commonClickListener2)
        databaseArrow.setOnClickListener(commonClickListener2)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            true
        } else super.onOptionsItemSelected(item)
    }

    private fun calculateDesiredHeight(listView: ListView): Int {
        val adapter = listView.adapter
        var totalHeight = 0
        val itemCount = adapter.count
        if (itemCount > 0) {
            val listItem = adapter.getView(0, null, listView)
            listItem.measure(
                View.MeasureSpec.UNSPECIFIED,
                View.MeasureSpec.UNSPECIFIED
            )
            totalHeight = listItem.measuredHeight * itemCount
            // Add divider height if the ListView has dividers
            totalHeight += (listView.dividerHeight * (itemCount - 1))
        }
        return totalHeight
    }
    override fun onBackPressed() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Logout !")
        builder.setMessage(
            "Are you sure to Logout ?"
        )
        builder.setPositiveButton("Logout") { dialog, which ->
            super.onBackPressed()
        }
        builder.setNegativeButton("Cancel") { dialog, which ->
        }
        builder.setCancelable(true)
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }
}